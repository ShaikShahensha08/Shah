﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.OrderManagement.API.Entities
{
    #region Class Definition
    /// <summary>
    /// Holds the properties for the order status
    /// </summary>
    public class OrderStatus
    {
        public int Id { get; set; }

        public string Status { get; set; }
    }
    #endregion
}
