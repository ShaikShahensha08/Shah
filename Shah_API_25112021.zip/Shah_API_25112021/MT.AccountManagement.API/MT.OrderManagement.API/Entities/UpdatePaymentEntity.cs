﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.OrderManagement.API.Entities
{
    public class UpdatePaymentEntity
    {
        public int PaymentId { get; set; }
        public string TransactionReferenceNo { get; set; }
        public int PaymentStatusId { get; set; }
    }
}
