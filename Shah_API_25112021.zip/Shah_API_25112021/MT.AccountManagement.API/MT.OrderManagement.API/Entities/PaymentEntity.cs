﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.OrderManagement.API.Entities
{
    public class PaymentEntity
    {
        public int OrderId { get; set; }
        public int PaymentTypeId { get; set; }
        public string Remarks { get; set; }
        public int CustomerId { get; set; }
    }
}
