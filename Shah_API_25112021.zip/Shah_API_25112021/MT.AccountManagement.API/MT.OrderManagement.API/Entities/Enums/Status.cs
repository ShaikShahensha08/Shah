﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.OrderManagement.API.Entities.Enums
{
    public enum Status
    {
        Initiated = 1,
        Processing = 2,
        Success = 3,
        Failure = 4
    }
}
