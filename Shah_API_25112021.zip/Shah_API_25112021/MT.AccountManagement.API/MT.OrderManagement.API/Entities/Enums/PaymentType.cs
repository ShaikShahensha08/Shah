﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.OrderManagement.API.Entities.Enums
{
    public enum PaymentType
    {
        Cash = 1,
        Debit = 2,
        Credit = 3,
        NoPayment = 4,
    }
}
