﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.OrderManagement.API.Entities
{
    public class OrderEntity
    {
        public int RestaurantId { get; set; }
        public int CustomerId { get; set; }
        public ICollection<OrderMenus> OrderMenuDetails { get; set; }
        public string DeliveryAddress { get; set; }
    }
}
