﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.OrderManagement.API.Entities
{
    public class CartItemsEntity
    {
        // Number of items in the cart
        public int CartItems { get; set; }
        // Item availability
        public bool IsItemAvailable { get; set; }
    }
}
