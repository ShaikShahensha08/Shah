﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.OrderManagement.API.Entities
{
    public class CustomerOrderReport
    {
        public int OrderId;
        public string OrderStatus { get; set; }
        public DateTime OrderedDate { get; set; }
        public string PaymentStatus { get; set; }
        public decimal price { get; set; }
    }
}
