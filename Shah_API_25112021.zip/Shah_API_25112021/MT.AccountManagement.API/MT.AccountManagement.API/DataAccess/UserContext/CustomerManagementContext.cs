﻿using Microsoft.EntityFrameworkCore;

namespace MT.AccountManagement.API.DataAccess.UserContext
{
    public partial class CustomerManagementContext : DbContext
    {
        //public CustomerManagementContext() : base()
        //{

        //}
        public CustomerManagementContext(DbContextOptions<CustomerManagementContext> context) : base(context)
        {

        }

        public virtual DbSet<LoggingInfo> LoggingInfo { get; set; }
        public virtual DbSet<TblCustomer> TblCustomer { get; set; }

        private string DB { get; }
        public CustomerManagementContext(string connectionstring)
        {
            DB = connectionstring;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                // optionsBuilder.UseSqlServer(DB);
                optionsBuilder.UseSqlServer("");
            }
        }

        
    }
}
