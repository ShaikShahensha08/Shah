﻿using SearchManagement.API.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Models
{
    public class MenuDetails
    {
        public TblOffer tbl_Offer { get; set; }
        public TblMenu tbl_Menu { get; set; }
        public TblCuisine tbl_Cuisine { get; set; }
    }
}
