﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Models
{
    public class SearchForRestaurant
    {
        public LocationDetails location { get; set; }
        public AdditionalFeatureForSearch search { get; set; }
    }
}
