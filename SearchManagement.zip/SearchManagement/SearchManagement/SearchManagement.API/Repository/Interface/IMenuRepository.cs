﻿using SearchManagement.API.DataModels;
using SearchManagement.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository
{
    public interface IMenuRepository : IRepository<TblMenu>
    {
        Task<IQueryable<MenuDetails>> GetRestaurantMenu(int restaurantID);
    }
}
