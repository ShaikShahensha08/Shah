﻿using SearchManagement.API.Data;
using SearchManagement.API.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository
{
    public class LoggingRepository : Repository<LoggingInfo>, ILoggingRepository
    {
        public LoggingRepository(RestaurantManagementContext context) : base(context) { }
    }
}
