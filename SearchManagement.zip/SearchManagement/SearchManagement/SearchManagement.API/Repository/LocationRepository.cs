﻿using SearchManagement.API.Data;
using SearchManagement.API.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Repository
{
    public class LocationRepository : Repository<TblLocation>, ILocationRepository
    {
        public LocationRepository(RestaurantManagementContext context) : base(context) { }
    }
}
