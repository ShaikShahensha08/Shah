﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Filters;
using SearchManagement.API.DataModels;
using SearchManagement.API.Repository;
using SearchManagement.API.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchManagement.API.Filters
{ 

    public class LoggingFilterAttribute : ActionFilterAttribute
    {
        private readonly IUnitofWork _unitofWork;
        public LoggingFilterAttribute(IUnitofWork unitofWork)
        {
            _unitofWork = unitofWork;
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            try
            {
                var controllerName = ((ControllerBase)context.Controller).ControllerContext.ActionDescriptor.ControllerName;
                var actionName = ((ControllerBase)context.Controller).ControllerContext.ActionDescriptor.ActionName;
                var controller = context.Controller as Controller;
                LoggingInfo info = new LoggingInfo()
                {
                    ActionName = actionName,
                    ControllerName = controllerName,
                    Description = "action executed at:" + DateTime.Now.ToString(),
                    RecordTimeStamp = DateTime.Now,
                };

                _unitofWork.LoggingRepository.Add(info);
                _unitofWork.Complete();
            }
            catch
            {
                throw new NotImplementedException();
            }
            base.OnActionExecuting(context);
        }
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            try
            {
                var controllerName = ((ControllerBase)context.Controller).ControllerContext.ActionDescriptor.ControllerName;
                var actionName = ((ControllerBase)context.Controller).ControllerContext.ActionDescriptor.ActionName;

                LoggingInfo info = new LoggingInfo()
                {
                    ActionName = actionName,
                    ControllerName = controllerName,
                    Description = "action executed at:" + DateTime.Now.ToString(),
                    RecordTimeStamp = DateTime.Now,
                };

                foreach (ParameterDescriptor item
                    in ((ControllerBase)context.Controller).ControllerContext.ActionDescriptor.Parameters)
                {
                    //print item.Key
                    //print item.Value
                }
                _unitofWork.LoggingRepository.Add(info);
                _unitofWork.Complete();

            }
            catch
            {
                throw new NotImplementedException();
            }
            base.OnActionExecuted(context);
        }
       
    }
}
