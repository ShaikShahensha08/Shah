﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.BusinessEntities
{
    class StockItems
    {
        public int RestaurantID { get; set; }
        public int Quantity { get; set; }
    }
}
