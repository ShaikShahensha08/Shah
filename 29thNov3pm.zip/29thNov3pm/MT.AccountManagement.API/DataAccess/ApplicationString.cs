﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.AccountManagement.API.DataAccess
{
    public class ApplicationString
    {
        private string _Db = "Data Source=vs2019vm\\SQLEXPRESS;Initial Catalog=AccountManagement;Integrated Security=True;";
        public string DB
        {
            get
            {
                return _Db;
            }
            set
            {
                _Db = value;
            }
        }
    }
}
