﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.AccountManagement.API.DataAccess
{
    public interface IUserDataAccess
    {
        TblCustomer UserLogin(string username, string password);
    }
}
