﻿using System;

namespace MT.AccountManagement.API.DataAccess.UserContext
{
    public class ModelBuilder
    {
        internal void Entity<T>(Action<object> p)
        {
            throw new NotImplementedException();
        }
    }
}