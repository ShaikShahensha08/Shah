﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.SearchBusinessEntities
{
    public string Restaurant_Name { get; set; }
    public double xaxis { get; set; }
    public double yaxis { get; set; }
    public double distance { get; set; }
}
