﻿using System;

namespace MT.SearchDataLayer
{
    public class Class1
    {
    }
}
