﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.SearchDataLayer.Repository
{
    public class ConnectionString
    {
        public string DatabaseConnectionString { get; set; }
    }
}
