﻿namespace MT.OnlineRestaurant.DataLayer.Repository
{
    public interface IOptions
    {
    }
}