﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.SearchDataLayer.DataEnitity
{
    class LocationDetails
    {
    }
}
