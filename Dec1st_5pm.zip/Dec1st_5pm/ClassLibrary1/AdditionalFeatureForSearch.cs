﻿using System;

namespace ClassLibrary1
{
    public class AdditionalFeatureForSearch
    {

        public int rating { get; set; }
        public string cuisine { get; set; }
        public string Menu { get; set; }
    }
}
