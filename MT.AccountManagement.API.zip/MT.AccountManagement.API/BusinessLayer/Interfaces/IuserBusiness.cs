﻿using MT.AccountManagement.API.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.AccountManagement.API.BusinessLayer.Interfaces
{
    public interface IUserBusiness
    {

        TblCustomer UserLogin(string username, string password);
    }
}
