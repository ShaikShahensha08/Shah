﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MT.AccountManagement.API.BusinessLayer
{

    /// <summary>
    /// Data Access Layer User
    /// </summary>
    public class UserBusiness : IUserBusiness
    {
        private readonly IUserDataAccess _userDataAccess;

        public UserBusiness(IUserDataAccess userDataAccess)
        {
            _userDataAccess = userDataAccess;
        }



        public TblCustomer UserLogin(string username, string password)
        {
            return _userDataAccess.UserLogin(username, password);
        }
    }
}
