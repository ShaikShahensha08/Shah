﻿namespace MT.AccountManagement.API.DataAccess.UserContext
{
    public class DbContext
    {
    }
}