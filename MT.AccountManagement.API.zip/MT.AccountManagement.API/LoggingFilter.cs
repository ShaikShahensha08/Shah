﻿using System;

namespace MT.AccountManagement.API
{
    internal class LoggingFilter : Type
    {
        private string v;

        public LoggingFilter(string v)
        {
            this.v = v;
        }
    }
}